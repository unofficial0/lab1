﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labbook1_3
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int choice  = Convert.ToInt32(args[0]);
            Switch S = new Switch(choice);




            Console.ReadKey();





        }
           

        
    }
}
