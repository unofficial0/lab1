﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labbook1_4
{
    class Program
    {
        public int Rollno { get; set; }
        public string Stuname { get; set; }
        public byte Age { get; set; }
        public char Gender { get; set; }
        public DateTime Dob { get; set; }
        public string Addr { get; set; }
        public float Percent { get; set; }


        static void Main(string[] args)
        {
            Console.WriteLine("enter the no of students");
            int id = Convert.ToInt32(Console.ReadLine());
            Program[] s = new Program[id];

            for (int i = 0; i < id; i++)
            {
                s[i] = new Program();

                Console.WriteLine("enter student rollno:");
                s[i].Rollno = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("enter student name:");
                s[i].Stuname = (Console.ReadLine());


                Console.WriteLine("enter student Age:");
                s[i].Age = Convert.ToByte(Console.ReadLine());

                Console.WriteLine("enter student Gender:");
                s[i].Gender = Convert.ToChar(Console.ReadLine());


                Console.WriteLine("enter student dOB:");
                s[i].Dob = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("enter student address:");
                s[i].Addr = Convert.ToString(Console.ReadLine());

                Console.WriteLine("enter student percentage:");
                s[i].Percent = float.Parse(Console.ReadLine());


            }
            for (int i = 0; i < id; i++)
            {
                Console.WriteLine($"student roll no is: {s[i].Rollno}");
                Console.WriteLine($"student name is: {s[i].Stuname}");
                Console.WriteLine($"student age is: {s[i].Age}");
                Console.WriteLine($"student gender is: {s[i].Gender }");
                Console.WriteLine($"student dob is: {s[i].Dob}");
                Console.WriteLine($"student address is: {s[i].Addr }");
                Console.WriteLine($"student  Percent  is: {s[i].Percent}");
            }
            Console.ReadKey();





        }
    }
}
