﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Employee;

namespace Labbook1_1
{
    class Program
    {
        static void Main(string[] args)
        {
           EmployeeDetails[] e= new EmployeeDetails[10];
            for (int i = 0; i < e.Length;i++)
            {
                e[i] = new EmployeeDetails();

                Console.Write("enter employee id: ");
                e[i].EmployeeId = Convert.ToInt32(Console.ReadLine());



                Console.Write("enter employee name:");
                e[i].EmployeeName = Console.ReadLine();

                Console.Write("enter address:");
                e[i].Address = Console.ReadLine();

                Console.Write("enter department:");
                e[i].Department = Console.ReadLine();

                Console.Write("enter city:");
                e[i].City = Console.ReadLine();

                Console.Write("enter salary:");
                e[i].Salary = Convert.ToDouble(Console.ReadLine());



                ////Console.WriteLine($"Employee name : {E[i].EmployeeName}");
                ////Console.WriteLine($"Employee salary : {E[i].Salary}");




            }


            List<EmployeeDetails> emp = new List<EmployeeDetails>(2);

            for (int i = 0; i <= 10; i++)
            {
                Console.WriteLine("{0},{1}", e[i].EmployeeName, e[i].Salary);
                Console.ReadKey();
            }



          

        }
    }
}
