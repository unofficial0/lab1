﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Arithmeticlibrary1;

namespace Labbook1_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter the two numbers:");
                int num1 = Convert.ToInt32(Console.ReadLine());
            double num2 = Convert.ToDouble(Console.ReadLine());
            caluculator.Add(num1, num2);
            caluculator.Subtract(num1, num2);
            caluculator.Multiply(num1, num2);
            caluculator.Divide(num1, num2);
            caluculator.Modulus(num1, num2);

            Console.ReadLine();
        }
    }
}
